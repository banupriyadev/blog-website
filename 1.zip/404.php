<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


    <link href="<?=ROOT?>/assets/bootstrap/bootstrap.min.css" rel="stylesheet">
</head>



<?php include('includes/header.php')?>

<body>
    <div class="text-center my-5 alert alert-danger">

    <h1>Page Not Found</h1>
    </div>    
   
</body>


<?php include('includes/footer.php')?>



<script src="<?=ROOT?>/assets/bootstrap/bootstrap.bundle.min.js"></script>

</html>

