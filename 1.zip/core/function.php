<?php

function query(string $query, array $data = []) {
    // Create a PDO connection (you might want to move this to a separate init or connection function)
    static $con = null; // Use static to ensure it persists across function calls

    if ($con === null) {
        try {
            $con = new PDO("mysql:host=" . DBHOST . ";dbname=" . DBNAME, DBUSER, DBPASS);
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Enable exceptions for errors
        } catch (PDOException $e) {
            die("Database connection error: " . $e->getMessage());
        }
    }

    $stm = $con->prepare($query); // Prepare the SQL statement

    // Execute the statement with bound parameters
    if (!$stm->execute($data)) {
        die("Error executing statement: " . implode(", ", $stm->errorInfo())); // Debugging
    }

    // Fetch the results
    $result = $stm->fetchAll(PDO::FETCH_ASSOC);
    return !empty($result) ? $result : false; // Return results or false if empty
}

function query_row(string $query, array $data = []) {
    // Create a PDO connection (you might want to move this to a separate init or connection function)
    static $con = null; // Use static to ensure it persists across function calls

    if ($con === null) {
        try {
            $con = new PDO("mysql:host=" . DBHOST . ";dbname=" . DBNAME, DBUSER, DBPASS);
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Enable exceptions for errors
        } catch (PDOException $e) {
            die("Database connection error: " . $e->getMessage());
        }
    }

    $stm = $con->prepare($query); // Prepare the SQL statement

    // Execute the statement with bound parameters
    if (!$stm->execute($data)) {
        die("Error executing statement: " . implode(", ", $stm->errorInfo())); // Debugging
    }

    // Fetch the results
    $result = $stm->fetchAll(PDO::FETCH_ASSOC);
    return !empty($result[0]) ? $result[0] : false; // Return results or false if empty
}






function redirect($page){
    header('Location:'.$page);
    die;

}

function old_value($key, $default = ''){

   if(!empty($_POST[$key])){
      return $_POST[$key];
   }
    return $default;  

}

function old_checked($key, $default = ''){
    if(!empty($_POST[$key]))
      return " checked";

    return "";  
}

function old_select($key, $value, $default = ''){
    if(!empty($_POST[$key]) && $_POST[$key] == $value)
    {
        return " selected";
    }
    elseif($default == $value){
        return " selected";
    }
      
    return "";  
}

function authenticate($row){
    $_SESSION['user'] = $row ;
}

function user($key = ''){
    if(empty($key)){
        return $_SESSION['user'];
    }
    if(!empty($_SESSION['user'][$key])){
        return $_SESSION['user'][$key];
    }

    return '';
}

function logged_in(){
    if(!empty($_SESSION['user'])){
        return true;
    }
    return false;
}

function str_to_url($url){
   $url = str_replace("'","",$url);
   $url = preg_replace('~[^\\pL0-9_]+~u', '-', $url);
   $url = trim($url,"-");
   $url = iconv("utf-8", "us-ascii//TRANSLIT", $url);
   $url = strtolower($url);
   $url = preg_replace('~[^-a-z0-9_]+~', '', $url);

   return $url; 
}

function get_image($filename) {
    // Check if filename is provided and not empty
    if (!empty($filename)) {
        // Define the image URL
        $imageUrl = '/blog-website/public/images/' . $filename;

        // Return the URL for the image
        return $imageUrl; // URL for <img>
    }
    
    // If no filename is provided, return the default image URL
    return '/assets/images/favicon.ico'; // URL for default image
}

//pagination

function get_pagination_vars(){
    //set page number
    $page_number = $_GET['page'] ?? 1;
    $page_number = empty($page_number) ? 1 : (int)$page_number;
    $page_number = $page_number <1 ? 1: $page_number;
    $current_link = $_GET['url'] ?? 'home';
    $current_link = ROOT. '/'. $current_link; 
    $query_string = '';

    foreach($_GET  as $key => $value){
        if($key != 'url'){
            $query_string .= "&" .$key."=".$value;
        }
        
    }
    if(!strstr($query_string, "page=")){
        $query_string .= "&page=".$page_number;
    }

    $query_string = trim($query_string, "&");
    $current_link .= "?".$query_string;

    $current_link = preg_replace("/page=.*/", "page=".$page_number, $current_link);
    $next_link = preg_replace("/page=.*/", "page=".($page_number+1), $current_link);
    $first_link = preg_replace("/page=.*/", "page=1", $current_link);
    $prev_page_number = $page_number < 2 ? 1 : $page_number - 1; 
    $prev_link = preg_replace("/page=.*/", "page=".$prev_page_number, $current_link);
    
    $result = ['current_link' => $current_link,
               'next_link'    => $next_link,
               'first_link'   => $first_link,
               'prev_link'    => $prev_link,
               'page_number'    => $page_number
              ];
    return $result;

}


function esc($str){
    return htmlspecialchars($str ?? '');
}


//create_tables();

function create_tables(){
    
    
    $string = "mysql:hostname=".DBHOST.";";
    

    try{
        $con = new PDO($string, DBUSER, DBPASS);

        $query = "CREATE DATABASE IF NOT EXISTS " . DBNAME; 
        $stm = $con->prepare($query);
        $stm->execute();

        $query = "USE " . DBNAME; 
        $stm = $con->prepare($query);
        $stm->execute();

        $query = "CREATE TABLE IF NOT EXISTS users(
        id int primary key auto_increment,
        username varchar(50) not null,
        email varchar(100) not null,
        password varchar(250) not null,
        image varchar(1024) null,
        date datetime default current_timestamp,
        role varchar(10) not null,
        
        key username (username),
        key email (email)

        )";
        $stm = $con->prepare($query);
        $stm->execute();
        
        $query = "CREATE TABLE IF NOT EXISTS categories(
        id int primary key auto_increment,
        category varchar(50) not null,
        slug varchar(100) not null,
        disabled tinyint default 0,

        key slug (slug),
        key caategory (category)
        )";
        
        $stm = $con->prepare($query);
        $stm->execute();


        /** posts **/
        $query = "CREATE TABLE IF NOT EXISTS post(
        id int primary key auto_increment,
        user_id int,
        category_id int,
        title varchar(100) not null,
        content text null,
        image varchar(1024) null,
        date datetime default current_timestamp,
        slug varchar(100) not null,


        key user_id (user_id),
        key category_id (category_id),
        key title (title),
        key slug (slug),
        key date (date)


        )";
        $stm = $con->prepare($query);
        $stm->execute();

    }
    catch(PDOException $e){
        echo "Error:".$e->getMessage();
    }
   
}



function resize_images($filename, $max_size = 1000){
    
   

    if(file_exists($filename)){
        $type = mime_content_type($filename);
        switch ($type){
            case 'image/jpeg':
                $image = imagecreatefromjpeg($filename);
                break;
            case 'image/png':
                $image = imagecreatefrompng($filename);
                break;
            case 'image/gif':
                $image = imagecreatefromgif($filename);
                break;
            case 'image/webp':
                $image = imagecreatefromwebp($filename);
                break;        
            default:
                return;
                break;    

        }

        $src_width = imagesx($image);
        $src_height = imagesy($image);

        if($src_width > $src_height){

            if($src_width < $max_size){
                $max_size = $src_width;
            }
            $dst_width = $max_size;
            $dst_height = ($src_height / $src_width) * $max_size;
        }
        else{
            if($src_height < $max_size){
                $max_size = $src_height;
            }
            $dst_height = $max_size;
            $dst_width = ($src_width / $src_height) * $max_size;
        }


        $dst_height = round($dst_height);
        $dst_width = round($dst_width);

        $dst_image = imagecreatetruecolor($dst_width, $dst_height);

        imagecopyresampled($dst_image, $image, 0, 0, 0, 0, $dst_width, $dst_height, $src_width, $src_height);
        
        switch ($type){
            case 'image/jpeg':
                imagejpeg($dst_image, $filename, 90);
                break;
            case 'image/png':
                imagepng($dst_image, $filename, 90);
                break;
            case 'image/gif':
                imagegif($dst_image, $filename, 90);
                break;
            case 'image/webp':
                imagewebp($dst_image, $filename, 90);
                break;        
            default:
                return;
                break;    

        }

        

        // echo $type;
        // die;
    }
   
}

function updateRedirectsInHtaccess() {
    // Fetch redirects from the database
    $redirectsQuery = "SELECT old_slug, new_slug FROM redirects";
    $redirects = query($redirectsQuery); // Assuming query() is your function to execute SQL

    $htaccessContent = "RewriteEngine On\n\n";

    // Create redirect rules
    foreach ($redirects as $redirect) {
        $htaccessContent .= "RewriteRule ^" . trim($redirect['old_slug'], '/') . "$ /" . trim($redirect['new_slug'], '/') . " [R=301,L]\n";
    }

    // Write to the .htaccess file
    if (file_put_contents(HTACCESS_PATH, $htaccessContent) === false) {
        echo "Failed to write to .htaccess file.";
    }
}


// phpinfo();
// die;

