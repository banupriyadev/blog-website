<?php

define('ROOT', "http://localhost:85/blog-website/public");
define('APP_NMAE', "My Blog");
