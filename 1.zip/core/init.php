<?php

//autoload required files
require 'connection.php';
require 'function.php';
require 'config.php';

