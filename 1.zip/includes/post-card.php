<div class="col-md-6">
     
          <div class="car-customdsd">
              <strong class="d-inline-block mb-2 text-primary-emphasis"><?=esc($row['category'] ?? 'Unknown');?></strong>
              <h3 class="mb-0 blog-listd"><a href="<?=ROOT?>/post/<?=$row['slug']?>"><?=esc($row['title']);?></a></h3>
              <div class="mb-1 text-body-secondary"><?=date("jS M, Y", strtotime($row['date']))?></div>
                <div class="card-text raiod-fid"><?=$row['meta_description']?></div>
                <a href="<?=ROOT?>/post/<?=$row['slug']?>" class="icon-link gap-1 blog-linkds">
                  Continue reading
                  
                </a>
             
              <div class="img-pars d-lg-block" >
                <a href="<?=ROOT?>/post/<?=$row['slug']?>">
                <img src="<?=ROOT?>/images/<?=esc($row['image']);?>" class="bd-placeholder-img w-md-100" width="400" height="250" style="object-fit:cover">
              
                </a>
              </div>
          </div>  
         
</div>