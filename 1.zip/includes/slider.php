<section class="weddig-sliders">
      <div class="container-fluid">
          <div id="myCarousel" class="carousel slide mb-6" data-bs-ride="carousel">
            <div class="carousel-indicators">
              <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
              <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
              
            </div>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="<?=ROOT?>/assets/images/indian-weddings.jpg" width="100%" height="500"  style="object-position:top;">
                <div class="container">
                  <div class="carousel-caption text-start">
                    <h1 class="abne-lisdsd">The Wedding Resource: Ideas, Advice, and Inspiration</h1>
                   
                  </div>
                </div>
              </div>
              <div class="carousel-item">
                <img src="<?=ROOT?>/assets/images/wedding-blogs.jpg" width="100%" height="500"  style="object-position:top;">
                
                <div class="container">
                  <div class="carousel-caption">
                    <h2 class="abne-lisdsd">All About Weddings: Resources for Every Bride and Groom</h2>
                   
                  </div>
                </div>
              </div>

              <div class="carousel-item">
                <img src="<?=ROOT?>/assets/images/christian-weddings.jpg" width="100%" height="500"  style="object-position:center;">
                
                <div class="container">
                  <div class="carousel-caption">
                    <h3  class="abne-lisdsd">Wedding Insights: Navigate Your Special Day</h3>
                   
                  </div>
                </div>
              </div>
            
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
         </div>      
      </div>

  </section>