<header class="p-3 mb-3 border-bottom">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 link-body-emphasis text-decoration-none">
        <img class="bi mb-2" src="<?=ROOT?>/assets/images/logo.png" alt="" width="50" height="65" style="object-fit:cover;">
        </a>

        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="<?=ROOT?>" class="nav-link px-2 link-secondary <?=$url[0] == 'home' ? 'active' : ''?>">Home</a></li>
          <li><a href="<?=ROOT?>/blog" class="nav-link px-2 link-body-emphasis <?=$url[0] == 'blog' ? 'active' : ''?>">Blog</a></li>
          
        </ul>
      
       
        
      <?php if(logged_in()):?>
        <div class="me-3">Hi, <?=user('username')?></div>
        <div class="dropdown text-end ">
          <a href="#" class="d-block link-body-emphasis text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="<?=get_image(user('image'));?>" alt="mdo" style="object-fit:cover;height:32px;min-width:32px" width="32" height="32" class="rounded-circle">
          </a>
          <ul class="dropdown-menu text-small">
          
            <li><a class="dropdown-item" href="#">Profile</a></li>
            <li><a class="dropdown-item" href="<?=ROOT?>/admin">Admin</a></li>
            <li><a class="dropdown-item" href="#">Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?=ROOT?>/logout">Sign out</a></li>
          </ul>
        </div>

        <?php elseif(empty(logged_in())):?> 
          
          <div class="dropdown text-end ">
          <a href="#" class="d-block link-body-emphasis text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="<?=ROOT?>/assets/images/profile-pic.png" alt="mdo" style="object-fit:cover;height:32px;min-width:32px" width="32" height="32" class="rounded-circle">
          </a>
          <ul class="dropdown-menu text-small">
          
            <li><a class="dropdown-item" href="<?=ROOT?>/login">Login</a></li>
            <li><a class="dropdown-item" href="<?=ROOT?>/signup">Register</a></li>
            
          </ul>
        </div>

      <?php  endif; ?>  
      </div>
    </div>
  </header>