<div class="container">
  <footer class="row row-cols-1 row-cols-sm-2 row-cols-md-5 py-5 mt-3 border-top align-items-center">
    <div class="col-md-3 mb-3">
      <a href="/" class="d-flex align-items-center mb-3 link-body-emphasis text-decoration-none">
      <img class="bi mb-2" src="<?=ROOT?>/assets/images/logo.png" alt="" width="148" height="100" style="object-fit:cover;">
      </a>
      <p class="text-body-secondary">&copy; 2024</p>
    </div>

    
    <div class="col-md-6 offset-md-3 mb-3">
    
      <ul class="nav fotdsfdf">
        <li class="nav-item mb-2"><a href="<?=ROOT?>/home" class="nav-link p-0 text-body-secondary">Home</a></li>
        <li class="nav-item mb-2"><a href="<?=ROOT?>/login" class="nav-link p-0 text-body-secondary">Login</a></li>
        <li class="nav-item mb-2"><a href="<?=ROOT?>/blog" class="nav-link p-0 text-body-secondary">Blog</a></li>
        <!-- <li class="nav-item mb-2"><a href="<?=ROOT?>/category" class="nav-link p-0 text-body-secondary">Category</a></li> -->
      </ul>
    </div>

    
    
  </footer>
</div>