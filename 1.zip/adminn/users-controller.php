<?php 
//add new
if($action == 'add'){
      if(!empty($_POST)) {

          //validate
          $errors = [];
        
          if(empty($_POST['username'])) {
              $errors['username'] = "A username is required";
          } elseif(!preg_match("/^[a-zA-Z]+$/", $_POST['username'])) {
              $errors['username'] = 'Username can only have letters and no space';
          }
          
          if (empty($_POST['email'])) {
            $errors['email'] = "An email is required";
          } else {
            // Validate email format
            if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                $errors['email'] = "Invalid email format";
            } else {
                // Proceed to check for existing email
                $query = "SELECT id FROM users WHERE email = :email";
                $params = ['email' => $_POST['email']];
                $emailResult = query($query, $params); // Execute query
        
                if ($emailResult) {
                    $errors['email'] = 'That email is already in use';
                }
            }
          }
        
        
          if(empty($_POST['password'])) {
              $errors['password'] = "A password is required";
          } elseif(strlen($_POST['password']) < 8) {
              $errors['password'] = 'Password must be 8 characters or more';
          }elseif($_POST['password'] !== $_POST['retype_password']) {
            $errors['password'] = 'passwords do not match to retype password';
          }
          

          // Define the upload directory
          $uploadDir = __DIR__ . '/../images/'; // Adjust according to your directory structure

          // Check if the directory exists, if not, create it
          if (!is_dir($uploadDir)) {
              mkdir($uploadDir, 0755, true); // Create the directory if it doesn't exist
          }

          $imagePath = ''; // Initialize the variable to store the image path

          if (!empty($_FILES['image']['name'])) {
              $allowed = ['image/jpeg', 'image/png', 'image/webp'];

              // Validate the image type
              if (!in_array($_FILES['image']['type'], $allowed)) {
                  $errors['image'] = 'Image format not supported';
              } else {
                  // Create a unique name for the image
                  $newImageName = time() . '_' . basename($_FILES['image']['name']);
                  $destination = $uploadDir . $newImageName; // Local path to save the image

                  // Move the uploaded file to the destination
                  if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                      
                      resize_images($destination);
                      // Success: Save the image name to be used in the database
                      $imagePath = $newImageName; // Store the new image name
                    

                  } else {
                      $errors['image'] = 'Failed to upload image';
                  }
              }
          }
        
          if(empty($errors)) {
              // Save to database
              $data = [
                  'username' => $_POST['username'],
                  'email'    => $_POST['email'],
                  'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                  'role'     => $_POST['role']
              ];
        
              if (!empty($imagePath)) {
                $data['image'] = $imagePath; // Assuming you have a column for the image in your DB
            }
        
            // Save to database
            $query = "INSERT INTO users(username, email, password, role" . (isset($data['image']) ? ', image' : '') . ") VALUES(:username, :email, :password, :role" . (isset($data['image']) ? ', :image' : '') . ")";
              query($query, $data);
              
              redirect('adminn/users');
          }
      }
    }
     

    elseif($action == 'edit'){
     
                  $query = "SELECT * FROM users WHERE id = :id LIMIT 1";
            $row = query_row($query, ['id' => $id]);

          if (!empty($_POST)) {    
              if ($row) {
                  // Initialize error array
                  $errors = [];

                  // Validate username
                  if (empty($_POST['username'])) {
                      $errors['username'] = 'Username is required';
                  } elseif (!preg_match("/^[a-zA-Z]+$/", $_POST['username'])) {
                      $errors['username'] = 'Username can only have letters and no spaces';
                  }

                  // Validate email
                  if (empty($_POST['email'])) {
                      $errors['email'] = "An email is required";
                  } else {
                      if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                          $errors['email'] = "Invalid email format";
                      } else {
                          $query = "SELECT id FROM users WHERE email = :email AND id != :id LIMIT 1";
                          $params = ['email' => $_POST['email'], 'id' => $id];
                          $emailResult = query($query, $params);

                          if ($emailResult) {
                              $errors['email'] = 'That email is already in use';
                          }
                      }
                  }

                  // Validate password
                  if (empty($_POST['password'])) {
                      // If no password, this is fine, do not add error
                  } elseif (strlen($_POST['password']) < 8) {
                      $errors['password'] = 'Password must be 8 characters or more';
                  } elseif ($_POST['password'] !== $_POST['retype_password']) {
                      $errors['password'] = 'Passwords do not match';
                  }

                     // Define the upload directory
                        $uploadDir = __DIR__ . '/../images/'; // Adjust according to your directory structure

                        // Check if the directory exists, if not, create it
                        if (!is_dir($uploadDir)) {
                            mkdir($uploadDir, 0755, true); // Create the directory if it doesn't exist
                        }

                        $imagePath = ''; // Initialize the variable to store the image path

                        if (!empty($_FILES['image']['name'])) {
                            $allowed = ['image/jpeg', 'image/png', 'image/webp'];

                            // Validate the image type
                            if (!in_array($_FILES['image']['type'], $allowed)) {
                                $errors['image'] = 'Image format not supported';
                            } else {
                                // Create a unique name for the image
                                $newImageName = time() . '_' . basename($_FILES['image']['name']);
                                $destination = $uploadDir . $newImageName; // Local path to save the image

                                // Move the uploaded file to the destination
                                if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                                    
                                    resize_images($destination);
                                    // Success: Save the image name to be used in the database
                                    $imagePath = $newImageName; // Store the new image name
                                  

                                } else {
                                    $errors['image'] = 'Failed to upload image';
                                }
                            }
                        }

                        // Check if there are no errors
                        if (empty($errors)) {
                            // Prepare data for update
                            $data = [
                                'username' => $_POST['username'],
                                'email'    => $_POST['email'],
                                'role'     => $_POST['role'],
                                'id'       => $id,
                            ];

                            // Include the image path if a new image was uploaded
                            if (!empty($imagePath)) {
                                $data['image'] = $imagePath; // Assume you have an image column in your database
                            }

                            // Check if password needs to be updated
                            if (!empty($_POST['password'])) {
                                $data['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
                                $query = "UPDATE users SET username = :username, email = :email, password = :password, role = :role" . 
                                        (!empty($imagePath) ? ', image = :image' : '') . 
                                        " WHERE id = :id LIMIT 1";
                            } else {
                                $query = "UPDATE users SET username = :username, email = :email, role = :role" . 
                                        (!empty($imagePath) ? ', image = :image' : '') . 
                                        " WHERE id = :id LIMIT 1";
                            }

                            // Execute the update
                            query($query, $data);

                            // Redirect after successful update
                            redirect('../public/admin/users');
                            exit; // Prevent further execution
                        }

          }
        }
    }

    elseif($action == 'delete'){
     
      $query = "SELECT * FROM users WHERE id = :id limit 1";
          $row = query_row($query, ['id'=>$id]);

      if($_SERVER['REQUEST_METHOD'] == 'POST'){    
         
          
        
        if($row){

          
          //validate
          $errors = [];
        
          if(empty($errors)) {
              // Save to database
              $data = [
                
                  'id'       => $id
              ];


              
              $query = "DELETE FROM users WHERE id = :id limit 1";
            
              query($query, $data);

             // Enable error reporting
                ini_set('display_errors', 1);
                ini_set('display_startup_errors', 1);
                error_reporting(E_ALL);

                // Assuming $row is an associative array with the key 'image'
                $uploadDir = 'images/'; // Define the directory where images are stored

                if (isset($row['image'])) {
                    $filePath = $uploadDir . $row['image'];
                    echo "Attempting to delete file at path: $filePath\n"; // Debugging output

                    // Check if the file exists
                    if (file_exists($filePath)) {
                        echo "File exists. Proceeding to delete...\n";
                        if (unlink($filePath)) {
                            echo "File deleted successfully: $filePath\n";
                        } else {
                            echo "Error deleting file: $filePath\n";
                            $lastError = error_get_last();
                            echo "Error details: " . print_r($lastError, true) . "\n"; // Output last error
                        }
                    } else {
                        echo "File does not exist: $filePath\n"; // File is not found
                    }
                } else {
                    echo "Image path not set in row array.\n"; // Handle unset path
                }

                header('Location: ../public/admin/users');
                exit; // Always use exit after a redirect 

          }
        }
        else{
          echo "record not found";
        }
      }  

    }
    
    
  