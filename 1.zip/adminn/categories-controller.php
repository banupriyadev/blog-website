<?php 
//add new
    if($action == 'add'){
      if(!empty($_POST)) {

          //validate
          $errors = [];
        
          if (empty($_POST['category'])) {
            $errors['category'] = "A category is required";
        } elseif (!preg_match("/^[a-zA-Z0-9\-\_\&\s]+$/", $_POST['category'])) {
            $errors['category'] = 'Category can only have letters, numbers, hyphens, underscores, ampersands, and spaces.';
        }
        
        // Function to convert the category name to a URL-friendly slug
        $slug = str_to_url($_POST['category']);
        
        // Check if the slug already exists in the database
        $query = "SELECT id FROM categories WHERE slug = :slug LIMIT 1";
        $existingSlug = query($query, ['slug' => $slug]); // Execute query
        
        // If slug exists, append a random number
        if ($existingSlug) {
            $slug .= rand(1000, 9999);
        }
        
        // If no errors, proceed to save to database
        if (empty($errors)) {
            // Prepare data for database insertion
            $data = [
                'category' => $_POST['category'],
                'slug'     => $slug,
                'disabled' => $_POST['disabled'] // Default to 0 if not set
            ];
        
            // Prepare the insert query
            $query = "INSERT INTO categories (category, slug, disabled) VALUES (:category, :slug, :disabled)";
            
            // Execute the insert query
            query($query, $data);
            
            // Redirect after successful insertion
            redirect('adminn/categories');
        }
      }
    }
     

    elseif($action == 'edit'){
     
                  $query = "SELECT * FROM categories WHERE id = :id LIMIT 1";
            $row = query_row($query, ['id' => $id]);

          if (!empty($_POST)) {    
              if ($row) {
                  // Initialize error array
                  $errors = [];

                  // Validate username
                  if (empty($_POST['category'])) {
                      $errors['category'] = 'Category is required';
                  } elseif (!preg_match("/^[a-zA-Z0-9\-\_\&\s]+$/", $_POST['category'])) {
                      $errors['category'] = 'Category can only have letters, numbers, hyphens, underscores, ampersands, and spaces.';
                  }

                 

                    
                        // Check if there are no errors
                        if (empty($errors)) {
                            // Prepare data for update
                            $data = [
                                'category' => $_POST['category'],
                                'disabled'     => $_POST['disabled'],
                                'id'       => $id,
                            ];

                            

                           
                            $query = "UPDATE categories SET category = :category, disabled = :disabled WHERE id = :id LIMIT 1";
                            

                            // Execute the update
                            query($query, $data);

                            // Redirect after successful update
                            redirect('../public/admin/categories');
                            exit; // Prevent further execution
                        }

          }
        }
    }

    elseif($action == 'delete'){
     
      $query = "SELECT * FROM categories WHERE id = :id limit 1";
          $row = query_row($query, ['id'=>$id]);

      if($_SERVER['REQUEST_METHOD'] == 'POST'){    
         
          
        
        if($row){

          
          //validate
          $errors = [];
        
          if(empty($errors)) {
              // Save to database
              $data = [
                
                  'id'       => $id
              ];


              
              $query = "DELETE FROM categories WHERE id = :id limit 1";
            
              query($query, $data);

                header('Location: ../public/admin/categories');
                exit; // Always use exit after a redirect 

          }
        }
        else{
          echo "record not found";
        }
      }  

    }
    
    
  