<?php 
//add new
    if($action == 'add'){
        if (!empty($_POST)) {
            // Initialize errors array
            $errors = [];

           
        
            // Validate title
            if (empty($_POST['title'])) {
                $errors['title'] = "Title is required";
            }

            if (empty($_POST['meta_description'])) {
                $errors['meta_description'] = "Meta Description is required";
            } elseif (strlen($_POST['meta_description']) < 130) {
                $errors['meta_description'] = "Meta Description must be at least 130 characters";
            } elseif (strlen($_POST['meta_description']) > 160) {
                $errors['meta_description'] = "Meta Description must not exceed 160 characters";
            }

            // Validate content
            if (empty($_POST['schema_markup'])) {
                $errors['schema_markup'] = "Schema is required";
            }
        

            if (empty($_POST['h_one'])) {
                $errors['h_one'] = "h1 is required";
            } elseif (strlen($_POST['h_one']) < 40) {
                $errors['h_one'] = "h1 must be at least 40 characters";
            } elseif (strlen($_POST['h_one']) > 100) {
                $errors['h_one'] = "h1 must not exceed 100 characters";
            }
        
            // Validate content
            if (empty($_POST['content'])) {
                $errors['content'] = "Content is required";
            }
        
            // Validate category_id
            if (empty($_POST['category_id'])) {
                $errors['category_id'] = "A category is required";
            }
        
            // Define the upload directory
            $uploadDir = __DIR__ . '/../images/';
        
            // Check if the directory exists, if not, create it
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
        
            $imagePath = ''; // Initialize the variable to store the image path
        
            // Check for image upload
            if (!empty($_FILES['image']['name'])) {
                // Check for upload errors
                if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
                    $errors['image'] = 'File upload error: ' . $_FILES['image']['error'];
                } else {
                    $allowed = ['image/jpeg', 'image/png', 'image/webp'];
        
                    // Validate the image type
                    if (!in_array($_FILES['image']['type'], $allowed)) {
                        $errors['image'] = 'Image format not supported';
                    } else {
                        // Create a unique name for the image
                        $newImageName = time() . '_' . basename($_FILES['image']['name']);
                        $destination = $uploadDir . $newImageName;
        
                        // Move the uploaded file to the destination
                        if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                            resize_images($destination);
                            $imagePath = $newImageName; // Store the new image name
                        } else {
                            $errors['image'] = 'Failed to upload image';
                        }
                    }
                }
            } else {
                $errors['image'] = "A featured image is required";
            }
        
            // Function to convert the title to a URL-friendly slug
            if (!empty($_POST['url'])) {
                $slug = str_to_url($_POST['url']);
        
                // Check if the slug already exists in the database
                $query = "SELECT id FROM categories WHERE slug = :slug LIMIT 1";
                $existingSlug = query($query, ['slug' => $slug]);
        
                // If slug exists, append a random number
                if ($existingSlug) {
                    $slug .= rand(1000, 9999);
                }
            }
        
            // Check if there are no errors
            if (empty($errors)) {
                // Prepare data for database insertion
                $data = [
                    'title' => $_POST['title'],
                    'meta_description' => $_POST['meta_description'],
                    'schema_markup' => $_POST['schema_markup'],
                    'h_one' => $_POST['h_one'],
                    'content' => $_POST['content'],
                    'slug' => $slug,
                    'user_id' => user('id'),
                    'category_id' => $_POST['category_id']
                ];
        
                if (!empty($imagePath)) {
                    $data['image'] = $imagePath; // Assuming you have a column for the image in your DB
                }
        
                // Save to database
                $query = "INSERT INTO post(title, meta_description, schema_markup, h_one, content, slug, category_id, user_id" . (isset($data['image']) ? ', image' : '') . ") VALUES(:title, :meta_description, :schema_markup, :h_one, :content, :slug, :category_id, :user_id" . (isset($data['image']) ? ', :image' : '') . ")";
                query($query, $data);
                
                redirect('adminn/posts');
            }
           
        }
        
    }
     

   
    elseif ($action == 'edit') {
        $query = "SELECT * FROM post WHERE id = :id LIMIT 1";
        $row = query_row($query, ['id' => $id]);
    
        if (!empty($_POST)) {
            if ($row) {
                // Initialize error array
                $errors = [];
    
                // Validate title
                if (empty($_POST['title'])) {
                    $errors['title'] = "Title is required";
                }
    
                // Validate other fields...
                if (empty($_POST['meta_description'])) {
                    $errors['meta_description'] = "Meta Description is required";
                } elseif (strlen($_POST['meta_description']) < 130) {
                    $errors['meta_description'] = "Meta Description must be at least 130 characters";
                } elseif (strlen($_POST['meta_description']) > 160) {
                    $errors['meta_description'] = "Meta Description must not exceed 160 characters";
                }
    
                if (empty($_POST['h_one'])) {
                    $errors['h_one'] = "h1 is required";
                } elseif (strlen($_POST['h_one']) < 40) {
                    $errors['h_one'] = "h1 must be at least 40 characters";
                } elseif (strlen($_POST['h_one']) > 100) {
                    $errors['h_one'] = "h1 must not exceed 100 characters";
                }
    
                if (empty($_POST['content'])) {
                    $errors['content'] = "Content is required";
                }
    
                if (empty($_POST['category_id'])) {
                    $errors['category_id'] = "A category is required";
                }
    
                // Define the upload directory
                $uploadDir = __DIR__ . '/../images/'; 
    
                // Check if the directory exists; if not, create it
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
    
                $imagePath = $row['image']; // Start with existing image path
    
                // Check if an image is being uploaded
                if (!empty($_FILES['image']['name'])) {
                    $allowed = ['image/jpeg', 'image/png', 'image/webp'];
    
                    // Validate the image type
                    if (!in_array($_FILES['image']['type'], $allowed)) {
                        $errors['image'] = 'Image format not supported';
                    } else {
                        // Create a unique name for the image
                        $newImageName = time() . '_' . basename($_FILES['image']['name']);
                        $destination = $uploadDir . $newImageName;
    
                        // Move the uploaded file to the destination
                        if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                            resize_images($destination); // Assuming this function is defined
                            $imagePath = $newImageName; // Update to new image name
                        } else {
                            $errors['image'] = 'Failed to upload image';
                        }
                    }
                }
    
                // Get the new slug from the input
                $slug = !empty($_POST['url']) ? str_to_url($_POST['url']) : '';
    
                // Check if the slug already exists in the database
                $oldSlug = $row['slug']; // Store the old slug
                $query = "SELECT id FROM post WHERE slug = :slug AND id != :id LIMIT 1";
                $existingSlug = query($query, ['slug' => $slug, 'id' => $id]);
    
                // If slug exists, append a random number
                if ($existingSlug) {
                    $slug .= rand(1000, 9999);
                }
    
                // Check if there are no errors
                if (empty($errors)) {
                    // Prepare data for update
                    $new_content = remove_images_from_content($_POST['content']); // Assuming this function is defined
    
                    $data = [
                        'title' => $_POST['title'],
                        'meta_description' => $_POST['meta_description'],
                        'h_one' => $_POST['h_one'],
                        'schema_markup' => $_POST['schema_markup'],
                        'content' => $new_content,
                        'id' => $id,
                        'slug' => $slug,
                        'category_id' => $_POST['category_id'],
                        'disabled' => $_POST['disabled'],
                        'image' => $imagePath // Updated image path
                    ];
    
                    // Build the update query
                    $query = "UPDATE post SET title = :title, meta_description = :meta_description, schema_markup = :schema_markup, h_one = :h_one, content = :content, category_id = :category_id, slug = :slug, disabled = :disabled, image = :image WHERE id = :id LIMIT 1";
    
                    // Execute the update
                    query($query, $data);
    
                    // Add a redirect for the old slug to the new slug
                // if ($oldSlug !== $slug) { // Only add redirect if the slug has changed
                //     // Check if the redirect already exists
                //     $checkQuery = "SELECT COUNT(*) FROM redirects WHERE old_slug = :old_slug AND new_slug = :new_slug";
                //     $exists = query($checkQuery, ['old_slug' => $oldSlug, 'new_slug' => $slug]);

                //     if ($exists[0] == 0) {
                //         $redirectQuery = "INSERT INTO redirects (old_slug, new_slug) VALUES (:old_slug, :new_slug)";
                //         query($redirectQuery, ['old_slug' => $oldSlug, 'new_slug' => $slug]);

                //         // Update the .htaccess file after inserting the redirect
                //         updateRedirectsInHtaccess();
                //     }
                // }
    
                    // Redirect after successful update
                    redirect('../public/admin/post');
                    exit;
                }
            }
        }
    }
    

    

    

    elseif($action == 'delete'){
     
      $query = "SELECT * FROM post WHERE id = :id limit 1";
          $row = query_row($query, ['id'=>$id]);

      if($_SERVER['REQUEST_METHOD'] == 'POST'){    
         
          
        
        if($row){

          
          //validate
          $errors = [];
        
          if(empty($errors)) {
              // Save to database
              $data = [
                
                  'id'       => $id
              ];


              
              $query = "DELETE FROM post WHERE id = :id limit 1";
            
              query($query, $data);

             // Enable error reporting
                ini_set('display_errors', 1);
                ini_set('display_startup_errors', 1);
                error_reporting(E_ALL);

                // Assuming $row is an associative array with the key 'image'
                $uploadDir = 'images/'; // Define the directory where images are stored

                if (isset($row['image'])) {
                    $filePath = $uploadDir . $row['image'];
                    echo "Attempting to delete file at path: $filePath\n"; // Debugging output

                    // Check if the file exists
                    if (file_exists($filePath)) {
                        echo "File exists. Proceeding to delete...\n";
                        if (unlink($filePath)) {
                            echo "File deleted successfully: $filePath\n";
                        } else {
                            echo "Error deleting file: $filePath\n";
                            $lastError = error_get_last();
                            echo "Error details: " . print_r($lastError, true) . "\n"; // Output last error
                        }
                    } else {
                        echo "File does not exist: $filePath\n"; // File is not found
                    }
                } else {
                    echo "Image path not set in row array.\n"; // Handle unset path
                }

                header('Location: ../public/admin/posts');
                exit; // Always use exit after a redirect 

          }
        }
        else{
          echo "record not found";
        }
      }  

    }
    
    


    function remove_images_from_content($content, $folder =  __DIR__ . '/../images/uploads/') {
        preg_match_all("/<img[^>]+/", $content, $matches);
    
        if (is_array($matches) && count($matches) > 0) {
            foreach ($matches[0] as $img) {
                // Check if the image source is base64 encoded
                if (!strstr($img, "data:")) {
                    continue; // Skip non-base64 images
                }
                preg_match('/src="([^"]+)"/', $img, $match);
                preg_match('/data-filename="([^"]+)"/', $img, $filenameMatch);
    
                if (!empty($match) && !empty($filenameMatch)) {
                    $base64Data = explode(',', $match[1])[1]; // Get the base64 part
                    $filename = ROOT. '/images/uploads/'. $filenameMatch[1];
    
                    // Create the uploads directory if it doesn't exist
                    if (!is_dir($folder)) {
                        mkdir($folder, 0755, true); // Create directory recursively
                    }
    
                    // Decode and save the file
                    file_put_contents($filename, base64_decode($base64Data));
    
                    // Replace the src in the content with the new filename
                    $content = str_replace($match[0], 'src="' . $filename . '"', $content);
                }
            }
        }
    
        return $content; // Return the modified content
       
    }
  