<?php if ($action == 'add'): ?>

    <link rel="stylesheet" type="text/css" href="<?=ROOT?>/assets/summernote/summernote-lite.css">


<div class="col-md-10 mx-auto">
    <form method="post" action="" enctype="multipart/form-data">
        <?php
        $image_src = isset($row) && isset($row['image']) ? get_image($row['image']) : ROOT . '/images/picture-icon.jpg';
        ?>
        
        <h1 class="h3 mb-3 fw-normal">Create An Account</h1>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">Please fix the errors below:</div>
        <?php endif; ?>

        <div class="my-2">
    Featured Image:<br>
    <label class="mx-auto d-block">
        <img class="mx-auto d-block image-preview-edit" src="<?= htmlspecialchars($image_src) ?>" style="cursor:pointer;width:150px; height:100px;object-fit:cover;">
        <input onchange="display_image_edit(this.files[0])" type="file" name="image" class="d-none">
    </label>
    <div class="mt-2">
        <input type="text" id="image-name-edit" name="image_name" class="form-control" placeholder="image name">
    </div>
    <script>
        function display_image_edit(file) {
            document.querySelector('.image-preview-edit').src = URL.createObjectURL(file);
            document.getElementById('image-name-edit').value = file.name; // Set the input value to the uploaded file name
        }
    </script>
</div>
        <?php if (!empty($errors["image"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["image"]) ?></div>
        <?php endif; ?>
        <div class="form-floating">
            <input name="url" value="<?= old_value('url') ?>" type="text" class="form-control mb-2" id="floatingUsername" placeholder="Title">
            <label for="floatingUsername">url</label>
        </div>
        <?php if (!empty($errors["url"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["url"]) ?></div>
        <?php endif; ?>
       

        <div class="form-floating">
            <input name="title" value="<?= old_value('title') ?>" type="text" class="form-control mb-2" id="floatingUsername" placeholder="Title">
            <label for="floatingUsername">Title</label>
        </div>
        <?php if (!empty($errors["title"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["title"]) ?></div>
        <?php endif; ?>

        <div class="form-floating">
            <input name="meta_description" value="<?= old_value('meta_description') ?>" type="text" class="form-control mb-2" id="floatingUsername" placeholder="Title">
            <label for="floatingUsername">Meta description</label>
        </div>
        <?php if (!empty($errors["meta_description"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["meta_description"]) ?></div>
        <?php endif; ?>

        <div class="">
            <textarea rows="3" name="schema_markup" class="form-control mb-2" id="floatingEmail" placeholder="schema markup"><?= old_value('schema_markup') ?></textarea>
        </div>
        <?php if (!empty($errors["schema_markup"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["schema_markup"]) ?></div>
        <?php endif; ?>

        <div class="form-floating">
            <input name="h_one" value="<?= old_value('h_one') ?>" type="text" class="form-control mb-2" id="floatingUsername" placeholder="Title">
            <label for="floatingUsername">h1</label>
        </div>
        <?php if (!empty($errors["h_one"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["h_one"]) ?></div>
        <?php endif; ?>

        <div class="">
            <textarea rows="8" name="content" class="form-control mb-2 summernote" id="floatingEmail" placeholder="Content"><?= old_value('content') ?></textarea>
        </div>
        <?php if (!empty($errors["content"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["content"]) ?></div>
        <?php endif; ?>

        <div class="form-floating my-3">
            <select name="category_id" id="category_id" class="form-select">
                <option value="">---Select---</option>
                <?php
                $query = "SELECT * FROM categories ORDER BY id DESC";
                $categories = query($query);
                if (!empty($categories)):
                    foreach ($categories as $cat): ?>
                        <option <?= old_select('category_id', $cat['id']) ?> value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['category']) ?></option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
            <label for="category_id">Category</label>
        </div>
        <?php if (!empty($errors["category_id"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["category_id"]) ?></div>
        <?php endif; ?>

        <a class="mt-4 btn btn-primary py-2" href="<?= ROOT ?>/admin/posts">Back</a>
        <button class="mt-4 btn btn-primary py-2 float-end" type="submit">Create A Post</button>
    </form>
</div>

<script src="<?=ROOT?>/assets/js/jquery.min.js"></script>
<script src="<?=ROOT?>/assets/summernote/summernote-lite.js"></script>

<script>
      $('.summernote').summernote({
        placeholder: 'Hello Bootstrap 4',
        tabsize: 2,
        height: 200
      });
    </script>

<?php elseif ($action == 'edit'): ?>

<link rel="stylesheet" type="text/css" href="<?=ROOT?>/assets/summernote/summernote-lite.css">

<div class="col-md-10 mx-auto">
    <form method="post" action="" enctype="multipart/form-data">
        <h1 class="h3 mb-3 fw-normal">Edit An Account</h1>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">Please fix the errors below:</div>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <div class="my-2">
    <label class="mx-auto d-block">
        <img class="mx-auto d-block image-preview-edit" src="<?= get_image($row['image']) ?>" style="cursor:pointer;width:80px; height:80px;object-fit:cover;">
        <input onchange="display_image_edit(this.files[0])" type="file" name="image" class="d-none">
    </label>
    <div class="mt-2">
        <input type="text" id="image-name-edit" name="image_name" value="<?= htmlspecialchars($row['image']) ?>" class="form-control" placeholder="Edit image name">
    </div>
</div>

<script>
    function display_image_edit(file) {
        // Check if the file is a valid image
        if (file && file.type.startsWith('image/')) {
            const imageUrl = URL.createObjectURL(file);
            document.querySelector('.image-preview-edit').src = imageUrl;
            document.getElementById('image-name-edit').value = file.name; // Set the input value to the file name
        } else {
            // Reset the image preview and input if the file is not valid
            document.querySelector('.image-preview-edit').src = 'default-image.jpg'; // Replace with a default image
            document.getElementById('image-name-edit').value = '';
        }
    }
</script>


<div class="form-floating">
            <input name="url" value="<?= old_value('url', $row['slug']) ?>" type="text" class="form-control mb-2" id="floatingUsername" placeholder="Title">
            <label for="floatingUsername">url</label>
        </div>
        <?php if (!empty($errors["url"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["url"]) ?></div>
        <?php endif; ?>


        <div class="form-floating">
            <input name="title" value="<?= old_value('title', $row['title']) ?>" type="text" class="form-control mb-2" id="floatingUsername" placeholder="Username">
            <label for="floatingUsername">Title</label>
        </div>
        <?php if (!empty($errors["title"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["title"]) ?></div>
        <?php endif; ?>
        <div class="form-floating">
            <input name="meta_description" value="<?= old_value('meta_description', $row['meta_description']) ?>" type="text" class="form-control mb-2" id="floatingUsername" placeholder="Title">
            <label for="floatingUsername">Meta description</label>
        </div>
        <?php if (!empty($errors["meta_description"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["meta_description"]) ?></div>
        <?php endif; ?>
        
        <div class="">
            <textarea rows="3" name="schema_markup" class="form-control mb-2" id="floatingEmail" placeholder="schema markup"><?= old_value('schema_markup', $row['schema_markup']) ?></textarea>
        </div>
        <?php if (!empty($errors["schema_markup"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["schema_markup"]) ?></div>
        <?php endif; ?>

        <div class="form-floating">
            <input name="h_one" value="<?= old_value('h_one', $row['h_one']) ?>" type="text" class="form-control mb-2" id="floatingUsername" placeholder="Title">
            <label for="floatingUsername">h1</label>
        </div>
        <?php if (!empty($errors["h_one"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["h_one"]) ?></div>
        <?php endif; ?>

        <div class="">
            <textarea rows="8" name="content" class="form-control mb-2 summernote" id="floatingEmail" placeholder="Content"><?= old_value('content', $row['content']) ?></textarea>
        </div>
        <?php if (!empty($errors["content"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["content"]) ?></div>
        <?php endif; ?>

        <div class="form-floating my-3">
            <select name="category_id" id="category_id" class="form-select">
                <option value="">---Select---</option>
                <?php
                $query = "SELECT * FROM categories ORDER BY id DESC";
                $categories = query($query);
                if (!empty($categories)):
                    foreach ($categories as $cat): ?>
                        <option <?= old_select('category_id', $cat['id'], $row['category_id']) ?> value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['category']) ?></option>
                    <?php endforeach;
                endif;
                ?>
            </select>
            <label for="category_id">Category</label>
        </div>
        <?php if (!empty($errors["category_id"])): ?>
            <div class="text-danger"><?= htmlspecialchars($errors["category_id"]) ?></div>
        <?php endif; ?>

        <div class="form-floating my-3" >
            <select name="disabled" class="form-select">
                 <option value="0" <?=old_select('disabled', '0', $row['disabled'])?>>Yes</option>
                 <option value="1" <?=old_select('disabled', '1', $row['disabled'])?>>No</option>
            </select>
            <label for="floatingEmail">Active</label>
        </div>

        <a class="mt-4 btn btn-primary py-2" href="<?= ROOT ?>/admin/posts">Back</a>
        <button class="mt-4 btn btn-primary py-2 float-end" type="submit">Save</button>
    </form>
</div>

    

<script src="<?=ROOT?>/assets/js/jquery.min.js"></script>
<script src="<?=ROOT?>/assets/summernote/summernote-lite.js"></script>

<script>
      $('.summernote').summernote({
        placeholder: 'Hello Bootstrap 4',
        tabsize: 2,
        height: 200
      });
    </script>

<?php elseif ($action == 'delete'): ?>

<div class="col-md-6 mx-auto">
    <form method="post" action="">
        <h1 class="h3 mb-3 fw-normal">Delete An Account</h1>
        <?php if (!empty($row)): ?>
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">Please fix the errors below:</div>
            <?php endif; ?>
            
            <div class="form-floating">
                <div class="form-control mb-2"><?= old_value('title', $row['title']) ?></div>
            </div>
            <?php if (!empty($errors["title"])): ?>
                <div class="text-danger"><?= htmlspecialchars($errors["title"]) ?></div>
            <?php endif; ?>

            <div class="form-floating">
                <div class="form-control mb-2"><?= old_value('slug', $row['slug']) ?></div>
            </div>
            <?php if (!empty($errors["slug"])): ?>
                <div class="text-danger"><?= htmlspecialchars($errors["slug"]) ?></div>
            <?php endif; ?>

            <a class="mt-4 btn btn-primary py-2" href="<?= ROOT ?>/admin/posts">Back</a>
            <button class="mt-4 btn btn-danger py-2 float-end" type="submit">Delete</button>
        <?php else: ?>
            <div class="alert alert-danger">Record Not Found</div>
        <?php endif; ?>
    </form>
</div>

<?php else: ?>

<h4>Posts <a href="<?= ROOT ?>/admin/posts/add" class="btn btn-primary">Add New</a></h4>
<div class="table-responsive tablgsd">
    <table class="table">
        <tr>
            <th>#</th>
            <th>Title</th>
            <th>Meta Description</th>
            <th>Slug</th>
            <th>h1</th>
            <th>Image</th>
            <th>Date</th>
            <th>Active</th>
            <th>Action</th>
        </tr>

        <?php
        $limit = 10;
        $offset = ($page['page_number'] - 1) * $limit;
        $query = "SELECT * FROM post ORDER BY id DESC LIMIT $limit OFFSET $offset";
        $rows = query($query);
        if (!empty($rows)):
            foreach ($rows as $row): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><p><?= htmlspecialchars($row['title']) ?></p></td>
                    <td><p><?= htmlspecialchars($row['meta_description']) ?></p></td>
                    <td><?= htmlspecialchars($row['slug']) ?></td>
                    <td><p><?= htmlspecialchars($row['h_one'])?></p></td>
                    <td><img src="<?= get_image($row['image']) ?>" style="height:50px; width:50px; object-fit:cover;"></td>
                    <td><?= date("jS M, Y", strtotime($row['date'])) ?></td>
                    <td><?= $row['disabled'] ? 'No' : 'Yes' ?></td>
                    <td>
                        <a class="btn btn-warning" href="<?= ROOT ?>/admin/posts/edit/<?= $row['id'] ?>">Edit</a>
                        <a class="btn btn-danger" href="<?= ROOT ?>/admin/posts/delete/<?= $row['id'] ?>">Delete</a>
                    </td>
                    
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6" class="text-center">No post found.</td>
            </tr>
        <?php endif; ?>
    </table>
    
    <div class="col-md-12 mb-4">
        <a class="btn btn-primary" href="<?= $page['first_link'] ?>">First Page</a>
        <a class="btn btn-primary" href="<?= $page['prev_link'] ?>">Prev Page</a>
        <a class="btn btn-primary float-end" href="<?= $page['next_link'] ?>">Next Page</a>
    </div>
</div>

<?php endif; ?>
