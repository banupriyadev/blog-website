<?php if($action == 'add'):?>

    <div class="col-md-6 mx-auto">
                <form method="post" action=""  enctype="multipart/form-data">
            
                <?php

// Set the image source based on the fetched data
$image_src = isset($row) && isset($row['image']) ? get_image($row['image']) : ROOT.'/assets/images/favicon.ico';
?>
               
            <h1 class="h3 mb-3 fw-normal">Create An Account</h1>
            <?php if(!empty($errors)): ?>
                <div class="alert alert-danger">Please fix the errors below</div>
            <?php endif; ?>

                    <div class="my-2">
                <label class="mx-auto d-block">
                    <img class="mx-auto d-block image-preview-edit" src="<?= $image_src ?>" style="cursor:pointer;width:80px; height:80px;object-fit:cover;">
                    <input onchange="display_image_edit(this.files[0])" type="file" name="image" class="d-none">
                </label>
                <script>
                    function display_image_edit(file) {
                        document.querySelector('.image-preview-edit').src = URL.createObjectURL(file);
                    }
                </script>
            </div>
            
            <div class="form-floating">
                <input name="username" value="<?=old_value('username')?>" type="text" class="form-control mb-2" id="floatingUsername" placeholder="Username">
                <label for="floatingUsername">Username</label>
            </div>
            <?php if(!empty($errors["username"])): ?>
                <div class="text-danger"><?=$errors["username"]?></div>
            <?php endif; ?>

            <div class="form-floating">
                <input name="email" value="<?=old_value('email')?>" type="email" class="form-control mb-2" id="floatingEmail" placeholder="name@example.com">
                <label for="floatingEmail">Email address</label>
            </div>
            <?php if(!empty($errors["email"])): ?>
                <div class="text-danger"><?=$errors["email"]?></div>
            <?php endif; ?>

            <div class="form-floating my-3">
                <select name="role" class="form-select">
                     <option value="User">User</option>
                     <option value="Admin">Admin</option>
                </select>
                <label for="floatingEmail">Role</label>
            </div>
            <?php if(!empty($errors["role"])): ?>
                <div class="text-danger"><?=$errors["role"]?></div>
            <?php endif; ?>

            <div class="form-floating">
                <input name="password" type="password" value="<?=old_value('password')?>"  class="form-control mb-2" id="floatingPassword" placeholder="Password">
                <label for="floatingPassword">Password</label>
            </div>
            <?php if(!empty($errors["password"])): ?>
                <div class="text-danger"><?=$errors["password"]?></div>
            <?php endif; ?>

            <div class="form-floating">
                <input name="retype_password" value="<?=old_value('retype_password')?>"  type="password" class="form-control mb-2" id="floatingRetypePassword" placeholder="Retype Password">
                <label for="floatingRetypePassword">Retype Password</label>
            </div>

            <a class="mt-4 btn btn-primary py-2"  href="<?=ROOT?>/admin/users">Back</a>
            <button class="mt-4 btn btn-primary py-2 float-end" type="submit">Create An Account</button>
            
            </form>
    </div>
   



<?php elseif($action == 'edit'):?>

    <div class="col-md-6 mx-auto">
                <form method="post" action="" enctype="multipart/form-data">
            
        
            <h1 class="h3 mb-3 fw-normal">Edit An Account</h1>
        <?php if(!empty($row)): ?>
            <?php if(!empty($errors)): ?>
                <div class="alert alert-danger">Please fix the errors below</div>
            <?php endif; ?>
            
            <div class="my-2">
                    <label class="mx-auto d-block">
                    <img class="mx-auto d-block image-preview-edit" src="<?= get_image($row['image']) ?>" style="cursor:pointer;;width:80px; height:80px;object-fit:cover;">
                    <input onchange="display_image_edit(this.files[0])" type="file" name="image" class="d-none">
                </label>
                 <script>
                    function display_image_edit(file){
                         document.querySelector('.image-preview-edit').src= URL.createObjectURL(file);
                    }
                 </script>
            </div>

            <div class="form-floating">
                <input name="username" value="<?=old_value('username', $row['username'])?>" type="text" class="form-control mb-2" id="floatingUsername" placeholder="Username">
                <label for="floatingUsername">Username</label>
            </div>
            <?php if(!empty($errors["username"])): ?>
                <div class="text-danger"><?=$errors["username"]?></div>
            <?php endif; ?>

            <div class="form-floating">
                <input name="email" value="<?=old_value('email', $row['email'])?>" type="email" class="form-control mb-2" id="floatingEmail" placeholder="name@example.com">
                <label for="floatingEmail">Email address</label>
            </div>
            <?php if(!empty($errors["email"])): ?>
                <div class="text-danger"><?=$errors["email"]?></div>
            <?php endif; ?>

            <div class="form-floating my-3" >
                <select name="role" class="form-select">
                     <option value="User" <?=old_select('role', 'User', $row['role'])?>>User</option>
                     <option value="Admin" <?=old_select('role', 'Admin', $row['role'])?>>Admin</option>
                </select>
                <label for="floatingEmail">Role</label>
            </div>
            <?php if(!empty($errors["role"])): ?>
                <div class="text-danger"><?=$errors["role"]?></div>
            <?php endif; ?>

            <div class="form-floating">
                <input name="password" type="password" value="<?=old_value('password')?>"  class="form-control mb-2" id="floatingPassword" placeholder="Password (leave empty tp keep old one)">
                <label for="floatingPassword">Password  (leave empty to keep old one)</label>
            </div>
            <?php if(!empty($errors["password"])): ?>
                <div class="text-danger"><?=$errors["password"]?></div>
            <?php endif; ?>

            <div class="form-floating">
                <input name="retype_password" value="<?=old_value('retype_password')?>"  type="password" class="form-control mb-2" id="floatingRetypePassword" placeholder="Retype Password">
                <label for="floatingRetypePassword">Retype Password</label>
            </div>

            <a class="mt-4 btn btn-primary py-2"  href="<?=ROOT?>/admin/users">Back</a>
            <button class="mt-4 btn btn-primary py-2 float-end" type="submit">Save</button>
            <?php else: ?>  
                <div class="alert alert-danger">Record Not Found</div>

        <?php endif; ?>  
            </form>
    </div>
   


<?php elseif($action == 'delete'):?>

    <div class="col-md-6 mx-auto">
                <form method="post" action="">
            

            <h1 class="h3 mb-3 fw-normal">Delete An Account</h1>
        <?php if(!empty($row)): ?>
            <?php if(!empty($errors)): ?>
                <div class="alert alert-danger">Please fix the errors below</div>
            <?php endif; ?>
            
            <div class="form-floating">
                <div  class="form-control mb-2"><?=old_value('username', $row['username'])?></div>
                
            </div>
            <?php if(!empty($errors["username"])): ?>
                <div class="text-danger"><?=$errors["username"]?></div>
            <?php endif; ?>

            <div class="form-floating">
            <div  class="form-control mb-2"><?=old_value('email', $row['email'])?></div>
            </div>
            <?php if(!empty($errors["email"])): ?>
                <div class="text-danger"><?=$errors["email"]?></div>
            <?php endif; ?>

            <a class="mt-4 btn btn-primary py-2"  href="<?=ROOT?>/admin/users">Back</a>
            <button class="mt-4 btn btn-danger py-2 float-end " type="submit">Delete</button>
            <?php else: ?>  
                <div class="alert alert-danger">Record Not Found</div>

        <?php endif; ?>  
            </form>
    </div>



<?php else: ?>
    <h4>Users <a href="<?=ROOT?>/admin/users/add" class="btn btn-primary">Add New</a></h4>
    <div class="table-responsive">
        <table class="table">
            <tr>
                <th>#</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Image</th>
                <th>Date</th>
                <th>Action</th>
            </tr>

            <?php
                $limit = 10;
                $offset = ($page['page_number'] - 1) * $limit;

                $query = "SELECT * FROM users ORDER BY id DESC limit $limit offset $offset";
                $rows = query($query);
            ?>

            <?php if (!empty($rows)): ?>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= esc($row['username']) ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['role'] ?></td>
                        <td><img src="<?= get_image($row['image']) ?>" style="height:50px; width:50px; object-fit:cover" ></td>
                        <!-- <td><img src="public/images/1727602664_wedding-diffficulties.jpg" style="height:50px; width:50px; object-fit:cover" ></td> -->
                        <td><?= date("jS M, Y", strtotime($row['date'])) ?></td>
                        <td>
                            <a class="btn btn-warning" href="<?=ROOT?>/admin/users/edit/<?=$row['id']?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                                </svg>
                            </a>
                            <a class="btn btn-danger" href="<?=ROOT?>/admin/users/delete/<?=$row['id']?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
                                    <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5M8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5m3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0"/>
                                </svg>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">No users found.</td>
                </tr>
            <?php endif; ?>
        </table>
        
        <div class="col-md-12 mb-4">
            <a class="btn btn-primary" href="<?=$page['first_link']?>">First Page</a>
            <a class="btn btn-primary" href="<?=$page['prev_link']?>">Prev Page</a>
            <a class="btn btn-primary float-end" href="<?=$page['next_link']?>">Next Page</a>
        </div>

    </div>
<?php endif; ?>