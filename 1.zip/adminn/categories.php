<?php if($action == 'add'):?>

<div class="col-md-6 mx-auto">
            <form method="post" action=""  enctype="multipart/form-data">
        
           
        <h1 class="h3 mb-3 fw-normal">Create Categories</h1>
        <?php if(!empty($errors)): ?>
            <div class="alert alert-danger">Please fix the errors below</div>
        <?php endif; ?>

                
        <div class="form-floating">
            <input name="category" value="<?=old_value('category')?>" type="text" class="form-control mb-2" id="floatingInput" placeholder="Username">
            <label for="floatingInput">Category</label>
        </div>
        <?php if(!empty($errors["category"])): ?>
            <div class="text-danger"><?=$errors["category"]?></div>
        <?php endif; ?>


        <div class="form-floating my-3">
            <select name="disabled" class="form-select">
                 <option value="0">Yes</option>
                 <option value="1">No</option>
            </select>
            <label for="floatingEmail">Active</label>
        </div>
        <?php if(!empty($errors["disabled"])): ?>
            <div class="text-danger"><?=$errors["disabled"]?></div>
        <?php endif; ?>

        
      

        <a class="mt-4 btn btn-primary py-2"  href="<?=ROOT?>/admin/categories">Back</a>
        <button class="mt-4 btn btn-primary py-2 float-end" type="submit">Create</button>
        
        </form>
</div>




<?php elseif($action == 'edit'):?>

<div class="col-md-6 mx-auto">
            <form method="post" action="" enctype="multipart/form-data">
        
    
        <h1 class="h3 mb-3 fw-normal">Edit An Categories</h1>
    <?php if(!empty($row)): ?>
        <?php if(!empty($errors)): ?>
            <div class="alert alert-danger">Please fix the errors below</div>
        <?php endif; ?>
        
       
        <div class="form-floating">
            <input name="category" value="<?=old_value('category', $row['category'])?>" type="text" class="form-control mb-2" id="floatingUsername" placeholder="Username">
            <label for="floatingUsername">category</label>
        </div>
        <?php if(!empty($errors["category"])): ?>
            <div class="text-danger"><?=$errors["category"]?></div>
        <?php endif; ?>

        

        <div class="form-floating my-3" >
            <select name="disabled" class="form-select">
                 <option value="0" <?=old_select('disabled', '0', $row['disabled'])?>>Yes</option>
                 <option value="1" <?=old_select('disabled', '1', $row['disabled'])?>>No</option>
            </select>
            <label for="floatingEmail">Active</label>
        </div>
        

        

        <a class="mt-4 btn btn-primary py-2"  href="<?=ROOT?>/admin/categories">Back</a>
        <button class="mt-4 btn btn-primary py-2 float-end" type="submit">Save</button>
        <?php else: ?>  
            <div class="alert alert-danger">Record Not Found</div>

    <?php endif; ?>  
        </form>
</div>



<?php elseif($action == 'delete'):?>

<div class="col-md-6 mx-auto">
            <form method="post" action="">
        

        <h1 class="h3 mb-3 fw-normal">Delete An Categories</h1>
    <?php if(!empty($row)): ?>
        <?php if(!empty($errors)): ?>
            <div class="alert alert-danger">Please fix the errors below</div>
        <?php endif; ?>
        
        <div class="form-floating">
            <div  class="form-control mb-2"><?=old_value('category', $row['category'])?></div>
            
        </div>
        <?php if(!empty($errors["category"])): ?>
            <div class="text-danger"><?=$errors["category"]?></div>
        <?php endif; ?>

        <div class="form-floating">
        <div  class="form-control mb-2"><?=old_value('disabled', $row['disabled'])?></div>
        </div>
        <?php if(!empty($errors["disabled"])): ?>
            <div class="text-danger"><?=$errors["disabled"]?></div>
        <?php endif; ?>

        <a class="mt-4 btn btn-primary py-2"  href="<?=ROOT?>/admin/categories">Back</a>
        <button class="mt-4 btn btn-danger py-2 float-end " type="submit">Delete</button>
        <?php else: ?>  
            <div class="alert alert-danger">Record Not Found</div>

    <?php endif; ?>  
        </form>
</div>



<?php else: ?>
<h4>Categories <a href="<?=ROOT?>/admin/categories/add" class="btn btn-primary">Add New</a></h4>
<div class="table-responsive">
    <table class="table">
        <tr>
            <th>#</th>
            <th>Category</th>
            <th>Slug</th>
            <th>Active</th>
            <th>Action</th>
        </tr>

        <?php
            $limit = 10;
            $offset = ($page['page_number'] - 1) * $limit;

            $query = "SELECT * FROM categories ORDER BY id DESC limit $limit offset $offset";
            $rows = query($query);
        ?>

        <?php if (!empty($rows)): ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= esc($row['category']) ?></td>
                    <td><?= $row['slug'] ?></td>
                    <td><?= $row['disabled'] ? 'No' : 'Yes' ?></td>
                    
                    <td>
                        <a class="btn btn-warning" href="<?=ROOT?>/admin/categories/edit/<?=$row['id']?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                            </svg>
                        </a>
                        <a class="btn btn-danger" href="<?=ROOT?>/admin/categories/delete/<?=$row['id']?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
                                <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5M8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5m3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0"/>
                            </svg>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7" class="text-center">No users found.</td>
            </tr>
        <?php endif; ?>
    </table>
    
    <div class="col-md-12 mb-4">
        <a class="btn btn-primary" href="<?=$page['first_link']?>">First Page</a>
        <a class="btn btn-primary" href="<?=$page['prev_link']?>">Prev Page</a>
        <a class="btn btn-primary float-end" href="<?=$page['next_link']?>">Next Page</a>
    </div>

</div>
<?php endif; ?>