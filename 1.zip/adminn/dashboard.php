<h4>Statistics</h4>

<div class="row justify-content-center">
    <div class="col-md-3 m-3 bg-light rounded shadow border text-center">
               <h3><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-video3" viewBox="0 0 16 16">
        <path d="M14 9.5a2 2 0 1 1-4 0 2 2 0 0 1 4 0m-6 5.7c0 .8.8.8.8.8h6.4s.8 0 .8-.8-.8-3.2-4-3.2-4 2.4-4 3.2"/>
        <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h5.243c.122-.326.295-.668.526-1H2a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v7.81c.353.23.656.496.91.783Q16 12.312 16 12V4a2 2 0 0 0-2-2z"/>
        </svg></h3>
        <div>
            Admin
        </div>
        <?php
        $query = "SELECT count(id) as num from users where role='admin'" ;
        $res = query_row($query);
        ?>
        <h3 class="text-primary"><?=$res['num'] ?? 0;?></h3>
    </div>
    <div class="col-md-3 m-3 bg-light rounded shadow border text-center">
               <h3><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
  <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
  <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
</svg></h3>
        <div>
            Users
        </div>
        <?php
        $query = "SELECT count(id) as num from users  where role='user'";
        $res = query_row($query);
        ?>
        <h3 class="text-primary"><?=$res['num'] ?? 0;?></h3>
    </div>
    <div class="col-md-3 m-3 bg-light rounded shadow border text-center">
               <h3><svg xmlns="http://www.w3.org/2000/svg" width="20" height="16" fill="currentColor" class="bi bi-tags" viewBox="0 0 16 16">
  <path d="M3 2v4.586l7 7L14.586 9l-7-7zM2 2a1 1 0 0 1 1-1h4.586a1 1 0 0 1 .707.293l7 7a1 1 0 0 1 0 1.414l-4.586 4.586a1 1 0 0 1-1.414 0l-7-7A1 1 0 0 1 2 6.586z"/>
  <path d="M5.5 5a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1m0 1a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3M1 7.086a1 1 0 0 0 .293.707L8.75 15.25l-.043.043a1 1 0 0 1-1.414 0l-7-7A1 1 0 0 1 0 7.586V3a1 1 0 0 1 1-1z"/>
</svg></h3>
        <div>
            Categories
        </div>
        <?php
        $query = "SELECT count(id) as num from categories";
        $res = query_row($query);
        ?>
        <h3 class="text-primary"><?=$res['num'] ?? 0;?></h3>
    </div>
    <div class="col-md-3 m-3 bg-light rounded shadow border text-center">
               <h3><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-file-post" viewBox="0 0 16 16">
  <path d="M4 3.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 .5.5v8a.5.5 0 0 1-.5.5h-7a.5.5 0 0 1-.5-.5z"/>
  <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2zm10-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1"/>
</svg></h3>
        <div>
            Posts
        </div>
        <?php
        $query = "SELECT count(id) as num from post";
        $res = query_row($query);
        ?>
        <h3 class="text-primary"><?=$res['num'] ?? 0;?></h3>
    </div>
</div>